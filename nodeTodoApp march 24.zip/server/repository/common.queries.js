
// TODO find by credentials
// allow any type of cred, username, email or _id

// TODO universal find one and update
// allow to pass a flag (object) of what to update
