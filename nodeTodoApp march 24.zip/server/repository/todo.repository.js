const createError = require('http-errors');
const Todo = require('../models/todo.schema');
const { updateTodoCount } = require('./user.repository');

module.exports.createTodo = async ({ title, description }, authorId) => {

  const todo = new Todo({
    title,
    description,
    createdAt: new Date(),
    authorId
  });

  await todo.save();
  await updateTodoCount(authorId);

  return todo;
}

// allow for searching, filtering and sorting
module.exports.getTodos = async (authorId) => {
  const todos = await Todo
    .find({ 'author.authorId': authorId })
    .sort({z: 1})
    .map(todo => delete todo.author);

  return todos;
}



module.exports.updateTodo = async (_id, body) => {
  const todo = await Todo.findOneAndUpdate(
    { _id },
    { $set: body },
    { new: true }
  );

  if (!todo) {
    throw createError(404, 'Todo not found');
  }

  return todo;
}

module.exports.deleteTodo = async _id => {
  const todo = await Todo.findOneAndRemove({ _id });

  if (!todo) {
    throw createError(404, 'Todo not found');
  }

}

module.exports.deleteAllTodos = async _id =>  await Todo.deleteMany({ _id });
