const createError = require('http-errors');
const User = require('../models/user.schema');
const { generateAuthToken, removeToken } = require('../service/authentication.service');
const { comparePassword } = require('../service/encryption.service');
const { welcomeEmail } = require('../service/email.service');

const findByCredentials = async (searchCriteria) => {

  const user = await User.findOne(searchCriteria);

  if (!user) {
    throw createError(404, 'User not found');
  }

  return user;
};


module.exports.createUser = async (userData) => {
  const user = new User(userData);
  await user.save();

  // perhaps save this for later when user is condfirmed by email
  const token = await generateAuthToken(user, 'auth'); // role auth, admin etc

  // welcomeEmail(user.email);

  return { user, token };
}

// Prevents user to log in if it's already logged in
const isAlreadyLoggedIn = (tokensArray) => tokensArray.length;

module.exports.loginUser = async ({ email, password }) => {

  const user = await findByCredentials({ email });

  if (isAlreadyLoggedIn(user.tokens)) {
    throw createError(400, 'User is already logged in');
  }

  // const bearerName = 'Trifecta';

  await comparePassword(password, user.password);

    // const token = `${bearerName} ${generateAuthToken(user, 'auth')}`;
  const token = await generateAuthToken(user, 'auth');

  return { user, token };
}

module.exports.updateTodoCount = async (authorId) => {

  const user = await User.findByIdAndUpdate(
    { _id: authorId },
    { $inc: { todosCreated: 1 } },
    { new: true }
  );

  if (!user) {
    throw createError(404, 'User not found');
  }

}

// FIND BY ID AND UPDATE => CREATE ONCE REUSE in AUTH REPO & USER REPO

module.exports.logoutUser = async (email) => {
  const { _id, tokens } = await findByCredentials({ email });

  if (!isAlreadyLoggedIn(tokens)) {
    throw createError(400, 'User is not logged in');
  }

  await removeToken(_id);
}

module.exports.findUser = async (searchCriteria) => findByCredentials(searchCriteria);
