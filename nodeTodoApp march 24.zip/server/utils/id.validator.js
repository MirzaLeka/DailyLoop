const { ObjectID } = require('mongodb');

module.exports = (id) => {
  if (!id || !ObjectID(id)) {
    return false
  }
  return true;
}
