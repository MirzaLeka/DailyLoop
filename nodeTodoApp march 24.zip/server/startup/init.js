const compression = require('compression');
const bodyParserConfig = require('./config/body-parser.config');

module.exports = (app, express) => {
  app
    .use(express.json(bodyParserConfig))
    .use(compression())
}
