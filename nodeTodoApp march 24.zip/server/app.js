const
  express = require('express'),
  app = express();

require('dotenv').config();
require('./db/mongoose');
require('./startup/init')(app, express);
require('./startup/security')(app);
require('./startup/routers')(app);
require('./startup/wrap-up')(app);

module.exports = { app };

// about:inspect
