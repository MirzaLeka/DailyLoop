const { isJWT } = require('validator');

module.exports = (token) => isJWT(token);
