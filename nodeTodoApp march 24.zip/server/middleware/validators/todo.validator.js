const createError = require('http-errors');
const cleanRequest = require('../utils/clean.util');
const validateObjectId = require('../../utils/id.validator');
const { validateTodoTitle, validateTodoDesciption } = require('../utils/todo.util');

module.exports.validateTodo = (req, res, next) => {

  if (!req.body) {
    throw createError(400, 'Invalid data provided');
  }

  req.body = cleanRequest(req.body);

  if (!validateTodoTitle(req.body.title)) {
    throw createError(422, 'Todo title needs to be within 100 characters long');
  }

  if (!validateTodoDesciption(req.body.description)) {
    throw createError(422, 'Todo description needs to be within 2000 characters long');
  }

  next();
}

module.exports.validateTodoId = (req, res, next) => {

  if (!validateObjectId(req.params._id)) {
    throw createError(400, 'Invalid data provided');
  }

  next();
}
