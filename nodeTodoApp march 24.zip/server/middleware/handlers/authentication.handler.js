const { findByToken } = require('../../service/authentication.service')
// const validateJWT = require('../validators/token.validator'); // will be used when you setup Bearer
const { isJWT } = require('validator');
const asyncHandler = require('express-async-handler');
const createError = require('http-errors');

const validateJWT = (token) => {

  if (!token || !isJWT(token)) {
    return false;
  }
  return true;
}

// throw createError won't work in async middleware because express 4.x can't handle promise rejections
// to allow that, I wrapped the entire thing with asyncHandler
module.exports.authenticateUser = asyncHandler(async (req, res, next) => {

  const token = req.header('x-auth');

  if (!validateJWT(token)) {
    throw createError(401);
  }

  const user = await findByToken(token);

  if (!user) {
    throw createError(403);
  }

  req.user = user;
  req.token = token;
  next();
});
