const router = require('express').Router();
const { createTodo, getTodos } = require('../repositorytodo.repository');

router

  .post('/', async (req, res, next) => {

    try {
      const newTodo = await createTodo(req.body, req.user._id);
      res.status(201).send(newTodo);

    } catch(e) {
      next(e);
    }

  })

  .get('/', async (req, res, next) => {

    try {
      const todos = await getTodos(req.user._id);
      res.send(todos);
    } catch (e) {
      next(e);
    }

  })

  .get('/:_id', async (req, res, next) => {

    try {
      const todos = await getTodos(req.user._id);
      res.send(todos);
    } catch (e) {
      next(e);
    }

  })

  .put('/:_id', async (req, res, next) => {

    try {
      const todos = await updateTodo(req.user._id, req.body);
      res.send(todos);
    } catch (e) {
      next(e);
    }

  })

  .delete('/:_id', async (req, res, next) => {

    try {
      await deleteTodo(req.user._id);
      res.send();
    } catch (e) {
      next(e);
    }

  })

  .delete('/all/:_id', async (req, res, next) => {

    try {
      await deleteAllTodos(req.user._id);
      res.send();
    } catch (e) {
      next(e);
    }

  })

module.exports = router;
