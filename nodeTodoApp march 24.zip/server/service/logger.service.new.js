
function LoggerService(repository) {

  const silent = process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'staging';

  const canLog = () => !silent && data;

  const log = data => canLog && repository.logToConsole(data);

//   const info = data => this.logToFile(this.createLogObject(data, 'info'));

//   const debug = data => this.logToFile(this.createLogObject(data, 'debug'));

//   const warn = data => this.logToFile(this.createLogObject(data, 'warn'));

//   const error = data => this.logToFile(this.createLogObject(data, 'error'));

  return {
    log
  }

}

module.exports = LoggerService;
