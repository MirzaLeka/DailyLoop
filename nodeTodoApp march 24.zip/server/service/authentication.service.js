const jwt = require('jsonwebtoken');
const createError = require('http-errors');
const User = require('../models/user.schema');
const validateObjectId = require('../utils/id.validator');

// this import causes user repository to fail
// could be because user repo is importing auth service and because of that you cannot also import user repo in auth service
// const { logoutUser } = require('../repository/user.repository')

// TODO Call Auth Service from User service, then Auth Service => User Repo

const { JWT_SECRET } = process.env;

const generateJWT = (payload) => {
    return new Promise((resolve, reject) => {
        jwt.sign(payload, JWT_SECRET, { expiresIn: '365d' }, (error, token) => {
            if (error) {
                return reject(error);
            }
            return resolve(token);
          });
    })
}

const verifyJWT = (token) => {
    return new Promise((resolve, reject) => {
        jwt.verify(token, JWT_SECRET, (error, payload) => {
            if (error) {
                return reject(error);
            }
            return resolve(payload);
        });

    });
}

// clears tokens array
const removeJWT = async (_id) => await User.findByIdAndUpdate( { _id }, { $set: { tokens: [] } });


module.exports.removeToken = async (id) => {

    if (!validateObjectId(id)) {
        throw createError(400, 'Invalid data provided');
    }

    return removeJWT(id);
};

module.exports.generateAuthToken = async (user, access) => {

    let token;

    try {
        token = await generateJWT({ _id: user._id.toHexString(), access });
    } catch(_) { }

    if (!token) {
        throw createError(500, 'Unable to generate token');
    }

    user.tokens = user.tokens.concat([{access, token}]);
    await user.save();

    return token;
}

module.exports.findByToken = async (token) => {

    let decoded;

    // this try catch here prevents response from exiting this method before getting to !decoded
    // weird!
    try {
        decoded = await verifyJWT(token);
    } catch(_) { }

    if (!decoded) {
        throw createError(403, 'Unable to verify JWT');
    }

    // user repository => find user by token
    return User
        .findOne({
            '_id': decoded._id,
            'tokens.token': token,  // filters tokens array and finds the match
            'tokens.access': decoded.access // makes no sense to my JS mind but it works
        })
    }