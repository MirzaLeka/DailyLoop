const logger = require('../service/logger.service');
const { PORT = 3000 } = process.env;

module.exports = (app) => {
  app
    .listen(PORT, () => logger.log({ message: `Server started on port ${PORT}` }));
}
