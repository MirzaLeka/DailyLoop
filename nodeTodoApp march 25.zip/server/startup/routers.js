const responseTime = require('response-time')
const errorHandler = require('../middleware/handlers/error.handler');
const rateLimiter = require('./config/limiter.config');
const toggleMaintenance = require('../middleware/handlers/maintenance.handler');

module.exports = (app) => {
  app
    .use(rateLimiter())
    .use('/health', require('../router/health.router'))
    .use('/maintenance', require('../router/maintenance.router'))
    .use(toggleMaintenance)
    .use(responseTime())
    .use('/api/users', require('../router/user.router'))
    // .use('/api/users', require('../router/todo.router'))
    // swagger
    .use(errorHandler)
}
