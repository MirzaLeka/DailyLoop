module.exports = (prop, minLength, maxLength) => prop.length <= maxLength && prop.length >= minLength;
