const
  express = require('express'),
  app = express();

process.on('uncaughtException', (error) => {
  console.log(error); // use logger
  // process.exit
})

process.on('unhandledRejection', (error) => {
  console.log(error); // use logger
  // process.exit
})

require('dotenv').config();
require('./db/mongoose');
require('./startup/init')(app, express);
require('./startup/security')(app);
require('./startup/routers')(app);
require('./startup/wrap-up')(app);

module.exports = { app };

// about:inspect
