module.exports = (service, repository) => {
  const serv = `../../service/${service}`;
  const repo = `../../repository/${repository}`;

  return require(serv)(require(repo));
}
