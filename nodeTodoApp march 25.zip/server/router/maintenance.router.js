const router = require('express').Router();
// const logger = require('../service/logger.service');
const validateMaintenance = require('../middleware/validators/maintenance.validator');

router

  .get('/', (req, res) => {
    res.send({ maintenanceMode: isMaintenance });
    // logger.log({ message: 'Maintenance status logged', payload: isMaintenance })
  })

  // update maintenance status
  .put('/toggle', validateMaintenance, (req, res) => {

    const response = {
      maintenanceMode: isMaintenance,
      message: 'Maintenance status updated'
    }

    res.status(202).send(response)
    // logger.warn({ message: 'Maintenance status updated', payload: isMaintenance, status: 202 })
  })

module.exports = router;
