const router = require('express').Router();
const generateHealthCheck = require('../service/health.service');
// const logger = require('../service/logger.service');

// process uptime() remains static inside service :/
const getUptime = () => `${(process.uptime()).toFixed(2)} s`;

router

  .get('/', (req, res) => {
    res.send({ uptime: getUptime(), healthCheck: generateHealthCheck() });
    // logger.info({ message: 'Server health checked' })
  })

module.exports = router;
