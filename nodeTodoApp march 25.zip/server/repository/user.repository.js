const createError = require('http-errors');
const User = require('../models/user.schema');
const { getCurrentDateTime } = require('../service/time.service');

// Prevents user to log in if it's already logged in
const isAlreadyLoggedIn = (tokensArray) => tokensArray.length;

// Find user by any search criteria
const findByCredentials = async (searchCriteria) => {

  const user = await User.findOne(searchCriteria);

  if (!user) {
    throw createError(404, 'User not found');
  }

  return user;
};


module.exports.updateUser = async (_id, criteria, newData = true) => {

  const user = await User.findByIdAndUpdate(
    { _id },
    criteria,
    { new: newData }
  );

  if (!user) {
    throw createError(404, 'User not found');
  }

}

module.exports.createUser = async ({ username, email, password }) => {

  const user = new User({
    username,
    email,
    password,
    dateRegistered: getCurrentDateTime()
  });

  await user.save();
  return user;
}


module.exports.loginUser = async ({ email }) => {

  const user = await findByCredentials({ email });

  if (isAlreadyLoggedIn(user.tokens)) {
    throw createError(400, 'User is already logged in');
  }

  return user;
}

// Do I even need this method? I can just pass criteria in the criteria updateUser it will work?
// maybe just add service method updateTodoCount update inside todo service that calls updateUser with criteria
module.exports.updateTodoCount = async (userId) => {

  return updateUser(userId, { $inc: { todosCreated: 1 } });

  // const user = await User.findByIdAndUpdate(
  //   { _id: authorId },
  //   { $inc: { todosCreated: 1 } },
  //   { new: true }
  // );

  // if (!user) {
  //   throw createError(404, 'User not found');
  // }

}

module.exports.logoutUser = async (email) => {
  const { _id, tokens } = await findByCredentials({ email });

  if (!isAlreadyLoggedIn(tokens)) {
    throw createError(400, 'User is not logged in');
  }

  return _id;
}

module.exports.findUser = async (searchCriteria) => findByCredentials(searchCriteria);
