const { createWriteStream } = require('fs');
const { randomBytes } = require('crypto');

const saveLog = data => {

  const silent = process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'staging';

  if (silent || !data) return;

  createWriteStream(`${data.level}.log`, {flags: 'a'})
    .end(`${JSON.stringify(data)}, \n`)
    .on('error', () => console.log('Unable to log!'));
}

const createLogObject = ({error = {}, req = {}, res = {}, message, payload, status, route}, level) => ({
  level,
  appVersion: process.env.npm_package_version,
  timestamp: getCurrentDateTime(),
  logId: generateLogId(),
  message: error.message || message,
  status: error.status || res.statusCode || status,
  stackTrace: error.stack,
  requestHeaders: req.headers,
  responseHeaders: res.getHeaders(),
  requestBody: req.body,
  responseBody: res.body || payload,
  endpoint: req.baseUrl || route,
  params: req.params,
  query: req.query
})

const createConsoleObject = ({ message, payload }, level) => ({
  level,
  appVersion: process.env.npm_package_version,
  timestamp: getCurrentDateTime(),
  message,
  payload
})

const generateLogId = () => randomBytes(16).toString('hex');

const getCurrentDateTime = () => 123;

logToConsole = data => {
  if (this.silent || !data) return;

  console.log(data);
}

const retrieveLog = (query) => {};

const deleteLogById = (query) => {};

const deleteAllLogs = (query) => {};
