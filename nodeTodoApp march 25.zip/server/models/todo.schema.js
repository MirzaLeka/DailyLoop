const { Schema, model } = require('mongoose');

const Todo = new Schema({
    title: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 100,
        trim: true
    },
    description: {
        type: String,
        required: false,
        minlength: 0,
        maxlength: 2000,
        trim: true,
        default: ''
    },
    status: {
        type: String,
        enum : ['new','in progress', 'done'],
        default: 'new'
    },
    createdAt: {
        type: String,
        default: ''
    },
    startedAt: {
        type: String,
        default: ''
    },
    completedAt: {
        type: String,
        default: ''
    },
    authorId: {
        type: Schema.Types.ObjectId,
        required: true
    }
});

module.exports = model('Todo', Todo);
