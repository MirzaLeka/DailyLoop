const { generateAuthToken, removeToken } = require('./authentication.service');
const { welcomeEmail } = require('./email.service');
const { comparePassword } = require('./encryption.service');

module.exports = (userRepository) => {

  const addUser = async (userData) => {
     const user = await userRepository.createUser(userData)

       // welcomeEmail(user.email);

     const token = await generateAuthToken(user, 'auth');

     return { user, token };

  };

  const loginUser = async (userData) => {

    const existingUser = await userRepository.loginUser(userData);

    await comparePassword(userData.password, existingUser.password);

    const token = await generateAuthToken(existingUser, 'auth');

    return { existingUser, token };
  }

  // validate email
  const logoutUser = async ({ email }) => {

    const _id = await userRepository.logoutUser(email);

    await removeToken(_id);
  }

  const getUser = async ({ email }) => userRepository.findUser(email);

  return { addUser, loginUser, logoutUser, getUser };
}
