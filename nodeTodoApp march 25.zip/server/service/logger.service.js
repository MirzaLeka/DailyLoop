const { createWriteStream } = require('fs');
const { randomBytes } = require('crypto');

class Logger {

  silent = process.env.NODE_ENV === 'test' || process.env.NODE_ENV === 'staging';

  log = data => this.logToConsole(this.createConsoleObject(data, 'info'));

  info = data => this.logToFile(this.createLogObject(data, 'info'));

  debug = data => this.logToFile(this.createLogObject(data, 'debug'));

  warn = data => this.logToFile(this.createLogObject(data, 'warn'));

  error = data => this.logToFile(this.createLogObject(data, 'error'));

  createLogObject = ({error = {}, req = {}, res = {}, message, payload, status, route}, level) => ({
    level,
    appVersion: process.env.npm_package_version,
    timestamp: new Date(),
    logId: randomBytes(16).toString('hex'),
    message: error.message || message,
    status: error.status || res.statusCode || status,
    stackTrace: error.stack,
    requestHeaders: req.headers,
    responseHeaders: res.getHeaders(),
    requestBody: req.body,
    responseBody: res.body || payload,
    endpoint: req.baseUrl || route,
    params: req.params,
    query: req.query
  })

  logToFile = data => {
    if (this.silent || !data) return;

    createWriteStream(`${data.level}.log`, {flags: 'a'})
      .end(`${JSON.stringify(data)}, \n`)
      .on('error', () => console.log('Unable to log!'));
  }

  createConsoleObject = ({ message, payload }, level) => ({
    level,
    appVersion: process.env.npm_package_version,
    timestamp: new Date(),
    message,
    payload
  })

  logToConsole = data => {
    if (this.silent || !data) return;

    console.log(data);
  }

  getCurrentDateTime() {
    const now = new Date();
    return new Date(
      Date.UTC(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        now.getUTCDate(),
        now.getUTCHours(),
        now.getUTCMinutes(),
        now.getUTCSeconds(),
        now.getUTCMilliseconds()
    )).toUTCString();
  }

}

module.exports = new Logger();
