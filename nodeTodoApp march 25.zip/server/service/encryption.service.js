const Cryptr = require('cryptr');
const bcrypt = require('bcryptjs');
const createError = require('http-errors');

const encryptDecrypt = (text, method) => new Cryptr(process.env.CRYPT_SECRET)[method](text);

module.exports.encrypt = (text) => encryptDecrypt(text, 'encrypt');

module.exports.decrypt = (text) => encryptDecrypt(text, 'decrypt');


const generateSalt = async () => {
    const saltRounds = 10;

    return new Promise((resolve, reject) => {
        bcrypt.genSalt(saltRounds, (error, salt) => {
            if (error) {
                return reject(error);
            }
            return resolve(salt);
        })
    });
};

const generateHash = async (text, salt) => {
    return new Promise((resolve, reject) => {
        bcrypt.hash(text, salt, (error, hash) => {
            if (error) {
                return reject(error);
            }
            return resolve(hash);
        });
    })
}

const compareHash = async (text1, text2) => {
    return new Promise((resolve, reject) => {
        bcrypt.compare(text1, text2, (error, match) => {
            if (match) {
                return resolve(true);
            }
            return reject(error);

        });
    });
}

module.exports.generateHashedPassword = async (password) => {

    let salt;

    try {
        salt = await generateSalt();
    } catch(_) {}

    if (!salt) {
        throw createError(500, 'Cannot generate salt');
    }

    let hashedPassword;

    try {
        hashedPassword = await generateHash(password, salt);
    } catch(_) {}

    if (!hashedPassword) {
        throw createError(500, 'Cannot hash password');
    }

    return hashedPassword;
}

module.exports.comparePassword = async (password, userPassword) => {

    let match = false;

    try {
        match = await compareHash(password, userPassword);
    } catch(_) { }

    if (!match) {
        throw createError(401);
    }

    return match;
}
