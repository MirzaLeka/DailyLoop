const { platform, totalmem, freemem, cpus } = require('os');
const { connection } = require('mongoose');
const { getCurrentDateTime } = require('./time.service');

const formatMemoryUsage = (data) => `${Math.round(data / 1024 / 1024 * 100) / 100} MB`
const formatOSMemory = (data) => `${(data / 1000_000_000).toFixed(2)} GB`


const memoryUsage = {
  rss: `${formatMemoryUsage(process.memoryUsage().rss)}`, // Resident Set Size - total memory allocated for the process execution
  heapTotal: `${formatMemoryUsage(process.memoryUsage().heapTotal)}`, // total size of the allocated heap
  heapUsed: `${formatMemoryUsage(process.memoryUsage().heapUsed)}`, // actual memory used during the execution
  external: `${formatMemoryUsage(process.memoryUsage().external)}`, // V8 external memory
};

const applicationInsights = {
  appVersion: process.env.npm_package_version,
  environment: process.env.NODE_ENV,
  activeProcess: process.pid,
  memoryUsage
};

const OSInsights = {
  platform: platform(),
  totalMemory: formatOSMemory(totalmem()),
  freeMemory: formatOSMemory(freemem()),
  cpu: {
    usage: {
      user: formatMemoryUsage(process.cpuUsage().user),
      system: formatMemoryUsage(process.cpuUsage().system),
    },
    count: cpus().length,
    details: cpus()
  }
}

const getConnectionStatus = {
  0: 'disconnected',
  1: 'connected',
  2: 'connecting',
  3: 'disconnecting'
}

// needs conditional logic
const getHealth = ()  => {
  switch (connection.readyState) {
    case 1:
    return { status: 200, message: 'Healthy' }
    case 2:
    return { status: 200, message: 'Processing' }
    case 3:
    return { status: 500, message: 'Problematic' }
    default:
    return { status: 503, message: 'Unstable' }
  }
}

module.exports = () => {
  return {
    app: applicationInsights,
    os: OSInsights,
    databaseStatus: getConnectionStatus[connection.readyState],
    overall: getHealth(),
    timestamp: getCurrentDateTime()
  }

}
